package project_1_LL_FR;

class Course {

    int id;
    String name;
    Course next;

    Course(int i,String n){
        id = i;
        name = n;
        next = null;
    }

    void display(){
        System.out.println(id+" "+name);
    }
}