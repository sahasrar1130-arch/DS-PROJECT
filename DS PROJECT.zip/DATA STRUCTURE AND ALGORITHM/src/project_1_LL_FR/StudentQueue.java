package project_1_LL_FR;

class StudentQueue {

    Student front = null;

    void enqueue(Student s) {

        if (front == null || s.marks > front.marks) {
            s.next = front;
            front = s;
        } else {

            Student temp = front;

            while (temp.next != null && temp.next.marks >= s.marks) {
                temp = temp.next;
            }

            s.next = temp.next;
            temp.next = s;
        }
    }

    Student dequeue() {

        if (front == null) {
            return null;
        }

        Student temp = front;
        front = front.next;
        temp.next = null;

        return temp;
    }

    void displayQueue() {

        if (front == null) {
            System.out.println("Queue Empty");
            return;
        }

        Student temp = front;

        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }
}