package project_1_LL_FR;

import java.io.*;

class FacultyManager {

    Faculty head = null;
    FacultyQueue fq = new FacultyQueue();

    int SIZE = 10;
    Faculty[] hashTable = new Faculty[SIZE];
    int hashFunction(int key) {
        return key % SIZE;
    }
    void insertIntoHash(Faculty f) {

        int index = hashFunction(f.id);

        Faculty newNode = new Faculty(f.id, f.name, f.subject);

        if (hashTable[index] == null) {
            hashTable[index] = newNode;
        } else {
            Faculty temp = hashTable[index];
            while (temp.next != null)
                temp = temp.next;
            temp.next = newNode;
        }
    }

    Faculty searchInHash(int id) {

        int index = hashFunction(id);

        Faculty temp = hashTable[index];

        while (temp != null) {
            if (temp.id == id)
                return temp;
            temp = temp.next;
        }

        return null;
    }
    void displayHashTable() {

        for (int i = 0; i < SIZE; i++) {
            System.out.print("Index " + i + ": ");

            Faculty temp = hashTable[i];

            while (temp != null) {
                System.out.print("[" + temp.id + ", " + temp.name + ", " + temp.subject + "] -> ");
                temp = temp.next;
            }

            System.out.println("null");
        }
    }

    void add(Faculty f){

        if(head == null)
            head = f;
        else{
            Faculty temp = head;
            while(temp.next != null)
                temp = temp.next;
            temp.next = f;
        }
    }

    void addFacultyManually(int id, String name, String subject){

        Faculty f = new Faculty(id, name, subject);

        add(f);
        insertIntoHash(f);

        saveFacultyToFile();
        System.out.println("Faculty Added & Saved");
    }

    void displayFaculty(){

        if(head == null){
            System.out.println("No Faculty Found");
            return;
        }

        Faculty temp = head;

        while(temp != null){
            temp.display();
            temp = temp.next;
        }
    }

    void deleteFaculty(int id){

        if(head == null){
            System.out.println("No Faculty Found");
            return;
        }

        if(head.id == id){
            head = head.next;
            saveFacultyToFile();
            System.out.println("Faculty Deleted");
            return;
        }

        Faculty temp = head;

        while(temp.next != null){

            if(temp.next.id == id){
                temp.next = temp.next.next;
                saveFacultyToFile();
                System.out.println("Faculty Deleted");
                return;
            }

            temp = temp.next;
        }

        System.out.println("Faculty Not Found");
    }

    void addFacultyToQueue(int id, String name, String subject){
        fq.enqueue(new Faculty(id, name, subject));
        System.out.println("Faculty Added To Queue");
    }

    void processFaculty(){
        Faculty f = fq.dequeue();
        if(f != null){
            add(f);
            insertIntoHash(f);
            saveFacultyToFile();
            System.out.println("Faculty Processed & Saved");
        } else {
            System.out.println("Queue Empty");
        }
    }

    void displayFacultyQueue(){
        fq.displayQueue();
    }

    void loadFacultyFromFile(){

        String filename = "src/project_1_LL_FR/faculty.txt";

        try{

            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;

            head = null;
            hashTable = new Faculty[SIZE];

            while((line = br.readLine()) != null){

                String data[] = line.split(" ");

                int id = Integer.parseInt(data[0]);
                String name = data[1];
                String subject = data[2];

                Faculty f = new Faculty(id, name, subject);

                add(f);
                insertIntoHash(f);
            }

            br.close();
            System.out.println("Faculty Loaded Successfully");

        }catch(IOException e){
            System.out.println("Error Reading Faculty File");
        }
    }

    void saveFacultyToFile(){

        String filename = "src/project_1_LL_FR/faculty.txt";

        try{

            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));

            Faculty temp = head;

            while(temp != null){
                bw.write(temp.id + " " + temp.name + " " + temp.subject);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();

        }catch(IOException e){
            System.out.println("Error Writing Faculty File");
        }
    }


    void heapify(Faculty[] arr, int n, int i) {

        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].id > arr[largest].id)
            largest = left;

        if (right < n && arr[right].id > arr[largest].id)
            largest = right;

        if (largest != i) {
            Faculty temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            heapify(arr, n, largest);
        }
    }

    void heapSort() {

        if (head == null) {
            System.out.println("No Faculty Found");
            return;
        }

        int count = 0;
        Faculty temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }

        Faculty[] arr = new Faculty[count];
        temp = head;

        for (int i = 0; i < count; i++) {
            arr[i] = temp;
            temp = temp.next;
        }

        for (int i = count / 2 - 1; i >= 0; i--) {
            heapify(arr, count, i);
        }

        for (int i = count - 1; i > 0; i--) {

            Faculty swap = arr[0];
            arr[0] = arr[i];
            arr[i] = swap;

            heapify(arr, i, 0);
        }

        head = arr[0];
        temp = head;

        for (int i = 1; i < count; i++) {
            temp.next = arr[i];
            temp = temp.next;
        }
        temp.next = null;

        System.out.println("Faculty Sorted Using Heap Sort");
    }
}