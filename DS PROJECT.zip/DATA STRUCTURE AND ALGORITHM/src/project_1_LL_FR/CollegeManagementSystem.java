package project_1_LL_FR;

import java.util.Scanner;

public class CollegeManagementSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        StudentManager sm = new StudentManager();
        CourseManager cm = new CourseManager();
        FacultyManager fm = new FacultyManager();

        sm.loadStudentsFromFile();
        cm.loadCoursesFromFile();
        fm.loadFacultyFromFile();

        int choice;

        do {

            System.out.println("\n===== College Management System =====");

            System.out.println("1 Load Students");
            System.out.println("2 Display Students");
            System.out.println("3 Search Student (Linear)");
            System.out.println("4 Sort Students (Bubble)");
            System.out.println("5 Add Student To Queue");
            System.out.println("6 Process Student Queue");
            System.out.println("7 Display Student Queue");
            System.out.println("8 Add Student To File");
            System.out.println("9 Delete Student");

            System.out.println("10 Load Courses");
            System.out.println("11 Display Courses");
            System.out.println("12 Add Course To File");
            System.out.println("13 Delete Course");

            System.out.println("14 Load Faculty");
            System.out.println("15 Display Faculty");
            System.out.println("16 Add Faculty To File");
            System.out.println("17 Delete Faculty");

            System.out.println("18 Add Course To Queue");
            System.out.println("19 Process Course Queue");
            System.out.println("20 Display Course Queue");

            System.out.println("21 Add Faculty To Queue");
            System.out.println("22 Process Faculty Queue");
            System.out.println("23 Display Faculty Queue");

            System.out.println("24 Search Student (Hash)");
            System.out.println("25 Display Student Hash Table");
            System.out.println("26 Search Course (Hash)");
            System.out.println("27 Display Course Hash Table");
            System.out.println("28 Search Faculty (Hash)");
            System.out.println("29 Display Faculty Hash Table");

            System.out.println("30 Heap Sort Students");
            System.out.println("31 Heap Sort Courses");
            System.out.println("32 Heap Sort Faculty");

            System.out.println("33 Exit");

            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    sm.loadStudentsFromFile();
                    break;

                case 2:
                    sm.displayStudents();
                    break;

                case 3:
                    System.out.print("Enter Roll: ");
                    sm.linearSearch(sc.nextInt());
                    break;

                case 4:
                    sm.bubbleSort();
                    break;

                case 5:
                    System.out.print("Roll: ");
                    int r = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String n = sc.nextLine();
                    System.out.print("Marks: ");
                    int m = sc.nextInt();
                    System.out.print("Attendance: ");
                    int a = sc.nextInt();
                    sm.addStudentToQueue(r, n, m, a);
                    break;

                case 6:
                    sm.processStudent();
                    break;

                case 7:
                    sm.displayQueue();
                    break;

                case 8: 
                    System.out.print("Roll: ");
                    int r1 = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String n1 = sc.nextLine();
                    System.out.print("Marks: ");
                    int m1 = sc.nextInt();
                    System.out.print("Attendance: ");
                    int a1 = sc.nextInt();
                    sm.addStudentManually(r1, n1, m1, a1);
                    break;

                case 9:
                    System.out.print("Enter Roll: ");
                    sm.deleteStudent(sc.nextInt());
                    break;

                case 10:
                    cm.loadCoursesFromFile();
                    break;

                case 11:
                    cm.displayCourses();
                    break;

                case 12:
                    System.out.print("Course ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String cname = sc.nextLine();
                    cm.addCourseManually(cid, cname);
                    break;

                case 13:
                    System.out.print("Enter Course ID: ");
                    cm.deleteCourse(sc.nextInt());
                    break;

                case 14:
                    fm.loadFacultyFromFile();
                    break;

                case 15:
                    fm.displayFaculty();
                    break;

                case 16:
                    System.out.print("Faculty ID: ");
                    int fid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String fname = sc.nextLine();
                    System.out.print("Subject: ");
                    String sub = sc.nextLine();
                    fm.addFacultyManually(fid, fname, sub);
                    break;

                case 17:
                    System.out.print("Enter Faculty ID: ");
                    fm.deleteFaculty(sc.nextInt());
                    break;

                case 18:
                    System.out.print("Course ID: ");
                    int cidq = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String cnameq = sc.nextLine();
                    cm.addCourseToQueue(cidq, cnameq);
                    break;

                case 19:
                    cm.processCourse();
                    break;

                case 20:
                    cm.displayCourseQueue();
                    break;

                case 21:
                    System.out.print("Faculty ID: ");
                    int fidq = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String fnameq = sc.nextLine();
                    System.out.print("Subject: ");
                    String subq = sc.nextLine();
                    fm.addFacultyToQueue(fidq, fnameq, subq);
                    break;

                case 22:
                    fm.processFaculty();
                    break;

                case 23:
                    fm.displayFacultyQueue();
                    break;

                case 24:
                    System.out.print("Enter Roll: ");
                    sm.hashSearch(sc.nextInt());
                    break;

                case 25:
                    sm.displayHashTable();
                    break;

                case 26:
                    System.out.print("Enter Course ID: ");
                    Course c = cm.searchInHash(sc.nextInt());
                    if (c != null) c.display();
                    else System.out.println("Course Not Found");
                    break;

                case 27:
                    cm.displayHashTable();
                    break;

                case 28:
                    System.out.print("Enter Faculty ID: ");
                    Faculty f = fm.searchInHash(sc.nextInt());
                    if (f != null) f.display();
                    else System.out.println("Faculty Not Found");
                    break;

                case 29:
                    fm.displayHashTable();
                    break;

                case 30:
                    sm.heapSort();
                    break;

                case 31:
                    cm.heapSort();
                    break;

                case 32:
                    fm.heapSort();
                    break;

                case 33:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid Choice");
            }

        } while (choice != 33);

        sc.close();
    }
}