package project_1_LL_FR;

class FacultyQueue {

    Faculty front = null;

    void enqueue(Faculty f) {

        if (front == null || f.id > front.id) {
            f.next = front;
            front = f;
        } else {

            Faculty temp = front;

            while (temp.next != null && temp.next.id >= f.id) {
                temp = temp.next;
            }

            f.next = temp.next;
            temp.next = f;
        }

        System.out.println("Faculty Added To Priority Queue");
    }

    Faculty dequeue() {

        if (front == null) {
            System.out.println("Faculty Queue Empty");
            return null;
        }

        Faculty temp = front;
        front = front.next;
        temp.next = null;

        return temp;
    }

    void displayQueue() {

        if (front == null) {
            System.out.println("Faculty Queue Empty");
            return;
        }

        Faculty temp = front;

        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }
}