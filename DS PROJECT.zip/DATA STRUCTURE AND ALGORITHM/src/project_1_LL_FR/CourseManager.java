package project_1_LL_FR;

import java.io.*;

class CourseManager {

    Course head = null;
    CourseQueue cq = new CourseQueue();

    int SIZE = 10;
    Course[] hashTable = new Course[SIZE];
    int hashFunction(int key) {
        return key % SIZE;
    }
    void insertIntoHash(Course c) {

        int index = hashFunction(c.id);

        Course newNode = new Course(c.id, c.name);

        if (hashTable[index] == null) {
            hashTable[index] = newNode;
        } else {
            Course temp = hashTable[index];
            while (temp.next != null)
                temp = temp.next;
            temp.next = newNode;
        }
    }
    Course searchInHash(int id) {

        int index = hashFunction(id);

        Course temp = hashTable[index];

        while (temp != null) {
            if (temp.id == id)
                return temp;
            temp = temp.next;
        }

        return null;
    }
    void displayHashTable() {

        for (int i = 0; i < SIZE; i++) {
            System.out.print("Index " + i + ": ");

            Course temp = hashTable[i];

            while (temp != null) {
                System.out.print("[" + temp.id + ", " + temp.name + "] -> ");
                temp = temp.next;
            }

            System.out.println("null");
        }
    }

    void add(Course c){

        if(head == null)
            head = c;
        else{
            Course temp = head;
            while(temp.next != null)
                temp = temp.next;
            temp.next = c;
        }
    }

    void addCourseManually(int id, String name){

        Course c = new Course(id, name);

        add(c);
        insertIntoHash(c);

        saveCoursesToFile();
        System.out.println("Course Added & Saved");
    }

    void displayCourses(){

        if(head == null){
            System.out.println("No Courses Found");
            return;
        }

        Course temp = head;

        while(temp != null){
            temp.display();
            temp = temp.next;
        }
    }

    void deleteCourse(int id){

        if(head == null){
            System.out.println("No Courses Found");
            return;
        }

        if(head.id == id){
            head = head.next;
            saveCoursesToFile();
            System.out.println("Course Deleted");
            return;
        }

        Course temp = head;

        while(temp.next != null){

            if(temp.next.id == id){
                temp.next = temp.next.next;
                saveCoursesToFile();
                System.out.println("Course Deleted");
                return;
            }

            temp = temp.next;
        }

        System.out.println("Course Not Found");
    }

    void addCourseToQueue(int id, String name){
        cq.enqueue(new Course(id, name));
        System.out.println("Course Added To Queue");
    }

    void processCourse(){
        Course c = cq.dequeue();
        if(c != null){
            add(c);
            insertIntoHash(c);
            saveCoursesToFile();
            System.out.println("Course Processed & Saved");
        } else {
            System.out.println("Queue Empty");
        }
    }

    void displayCourseQueue(){
        cq.displayQueue();
    }

    void loadCoursesFromFile(){

        String filename = "src/project_1_LL_FR/courses.txt";

        try{

            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;

            head = null;
            hashTable = new Course[SIZE];

            while((line = br.readLine()) != null){

                String data[] = line.split(" ");

                int id = Integer.parseInt(data[0]);
                String name = data[1];

                Course c = new Course(id, name);

                add(c);
                insertIntoHash(c);
            }

            br.close();
            System.out.println("Courses Loaded Successfully");

        }catch(IOException e){
            System.out.println("Error Reading Course File");
        }
    }

    void saveCoursesToFile(){

        String filename = "src/project_1_LL_FR/courses.txt";

        try{

            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));

            Course temp = head;

            while(temp != null){
                bw.write(temp.id + " " + temp.name);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();

        }catch(IOException e){
            System.out.println("Error Writing Course File");
        }
    }


    void heapify(Course[] arr, int n, int i) {

        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].id > arr[largest].id)
            largest = left;

        if (right < n && arr[right].id > arr[largest].id)
            largest = right;

        if (largest != i) {
            Course temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            heapify(arr, n, largest);
        }
    }

    void heapSort() {

        if (head == null) {
            System.out.println("No Courses Found");
            return;
        }

        int count = 0;
        Course temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }

        Course[] arr = new Course[count];
        temp = head;

        for (int i = 0; i < count; i++) {
            arr[i] = temp;
            temp = temp.next;
        }

        for (int i = count / 2 - 1; i >= 0; i--) {
            heapify(arr, count, i);
        }

        for (int i = count - 1; i > 0; i--) {

            Course swap = arr[0];
            arr[0] = arr[i];
            arr[i] = swap;

            heapify(arr, i, 0);
        }

        head = arr[0];
        temp = head;

        for (int i = 1; i < count; i++) {
            temp.next = arr[i];
            temp = temp.next;
        }
        temp.next = null;

        System.out.println("Courses Sorted Using Heap Sort");
    }
}