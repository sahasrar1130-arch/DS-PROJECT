package project_1_LL_FR;

class CourseQueue {

    Course front = null;

    void enqueue(Course c) {

        if (front == null || c.id > front.id) {
            c.next = front;
            front = c;
        } else {

            Course temp = front;

            while (temp.next != null && temp.next.id >= c.id) {
                temp = temp.next;
            }

            c.next = temp.next;
            temp.next = c;
        }

        System.out.println("Course Added To Priority Queue");
    }

    Course dequeue() {

        if (front == null) {
            System.out.println("Course Queue Empty");
            return null;
        }

        Course temp = front;
        front = front.next;
        temp.next = null;

        return temp;
    }

    void displayQueue() {

        if (front == null) {
            System.out.println("Course Queue Empty");
            return;
        }

        Course temp = front;

        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }
}