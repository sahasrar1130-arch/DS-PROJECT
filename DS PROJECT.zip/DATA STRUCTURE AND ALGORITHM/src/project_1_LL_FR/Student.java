package project_1_LL_FR;

class Student {

    int rollNo;
    String name;
    int marks;
    int attendance;

    Student next;

    Student(int r, String n, int m, int a) {
        rollNo = r;
        name = n;
        marks = m;
        attendance = a;
        next = null;
    }

    void display() {
        System.out.println(rollNo + " " + name + " " + marks + " " + attendance);
    }
}