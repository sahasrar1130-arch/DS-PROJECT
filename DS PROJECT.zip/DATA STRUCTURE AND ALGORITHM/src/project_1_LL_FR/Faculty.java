package project_1_LL_FR;

class Faculty {

    int id;
    String name;
    String subject;

    Faculty next;

    Faculty(int i,String n,String s){

        id = i;
        name = n;
        subject = s;
        next = null;
    }

    void display(){
        System.out.println(id+" "+name+" "+subject);
    }
}