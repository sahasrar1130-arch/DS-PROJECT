package project_1_LL_FR;

import java.io.*;

class StudentManager {

    Student head = null;
    StudentQueue queue = new StudentQueue();

    int SIZE = 10;
    Student[] hashTable = new Student[SIZE];

    int hashFunction(int key) {
        return key % SIZE;
    }


    void insertIntoHash(Student s) {

        int index = hashFunction(s.rollNo);

        Student newNode = new Student(s.rollNo, s.name, s.marks, s.attendance);

        if (hashTable[index] == null) {
            hashTable[index] = newNode;
        } else {
            Student temp = hashTable[index];
            while (temp.next != null)
                temp = temp.next;
            temp.next = newNode;
        }
    }

 
    Student searchInHash(int roll) {

        int index = hashFunction(roll);

        Student temp = hashTable[index];

        while (temp != null) {
            if (temp.rollNo == roll)
                return temp;
            temp = temp.next;
        }

        return null;
    }

    void displayHashTable() {

        for (int i = 0; i < SIZE; i++) {
            System.out.print("Index " + i + ": ");

            Student temp = hashTable[i];

            while (temp != null) {
                System.out.print("[" + temp.rollNo + ", " + temp.name + ", " + temp.marks + ", " + temp.attendance + "] -> ");
                temp = temp.next;
            }

            System.out.println("null");
        }
    }

    void add(Student s) {

        if (head == null)
            head = s;
        else {
            Student temp = head;
            while (temp.next != null)
                temp = temp.next;
            temp.next = s;
        }

        insertIntoHash(s);
    }

    void saveStudentsToFile() {

        String filename = "src/project_1_LL_FR/students.txt";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));

            Student temp = head;

            while (temp != null) {
                bw.write(temp.rollNo + " " + temp.name + " " + temp.marks + " " + temp.attendance);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();
        } catch (IOException e) {
            System.out.println("Error writing file");
        }
    }

    void loadStudentsFromFile() {

        String filename = "src/project_1_LL_FR/students.txt";

        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;

            head = null;
            hashTable = new Student[SIZE];

            while ((line = br.readLine()) != null) {

                if (line.trim().isEmpty()) continue;

                String data[] = line.split(" ");

                if (data.length < 4) continue;

                int roll = Integer.parseInt(data[0]);
                String name = data[1];
                int marks = Integer.parseInt(data[2]);
                int attendance = Integer.parseInt(data[3]);

                add(new Student(roll, name, marks, attendance));
            }

            br.close();
            System.out.println("Students Loaded");

        } catch (IOException e) {
            System.out.println("Error reading file");
        }
    }

    void addStudentToQueue(int r, String n, int m, int a) {
        queue.enqueue(new Student(r, n, m, a));
    }

    void processStudent() {

        Student s = queue.dequeue();

        if (s != null) {
            add(s);
            saveStudentsToFile();
            System.out.println("Processed & Saved");
        } else {
            System.out.println("Queue Empty");
        }
    }

    void displayQueue() {
        queue.displayQueue();
    }

    void displayStudents() {

        if (head == null) {
            System.out.println("No Students");
            return;
        }

        Student temp = head;

        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }

    void linearSearch(int roll) {

        Student temp = head;

        while (temp != null) {
            if (temp.rollNo == roll) {
                temp.display();
                return;
            }
            temp = temp.next;
        }

        System.out.println("Not Found");
    }

    void hashSearch(int roll) {

        Student s = searchInHash(roll);

        if (s != null)
            s.display();
        else
            System.out.println("Not Found");
    }

    void bubbleSort() {

        for (Student i = head; i != null; i = i.next) {

            for (Student j = head; j.next != null; j = j.next) {

                if (j.marks < j.next.marks) {

                    int r = j.rollNo;
                    String n = j.name;
                    int m = j.marks;
                    int a = j.attendance;

                    j.rollNo = j.next.rollNo;
                    j.name = j.next.name;
                    j.marks = j.next.marks;
                    j.attendance = j.next.attendance;

                    j.next.rollNo = r;
                    j.next.name = n;
                    j.next.marks = m;
                    j.next.attendance = a;
                }
            }
        }

        System.out.println("Sorted using Bubble Sort");
    }



    void heapify(Student[] arr, int n, int i) {

        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left].marks > arr[largest].marks)
            largest = left;

        if (right < n && arr[right].marks > arr[largest].marks)
            largest = right;

        if (largest != i) {
            Student temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            heapify(arr, n, largest);
        }
    }

    void heapSort() {

        if (head == null) {
            System.out.println("No Students");
            return;
        }

        int count = 0;
        Student temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }

        Student[] arr = new Student[count];
        temp = head;

        for (int i = 0; i < count; i++) {
            arr[i] = temp;
            temp = temp.next;
        }

        for (int i = count / 2 - 1; i >= 0; i--) {
            heapify(arr, count, i);
        }

        for (int i = count - 1; i > 0; i--) {

            Student swap = arr[0];
            arr[0] = arr[i];
            arr[i] = swap;

            heapify(arr, i, 0);
        }

        head = arr[0];
        temp = head;

        for (int i = 1; i < count; i++) {
            temp.next = arr[i];
            temp = temp.next;
        }
        temp.next = null;

        System.out.println("Students Sorted Using Heap Sort (by Marks)");
    }

    void addStudentManually(int r, String n, int m, int a) {

        add(new Student(r, n, m, a));
        saveStudentsToFile();

        System.out.println("Added & Saved");
    }

    void deleteStudent(int roll) {

        if (head == null) return;

        if (head.rollNo == roll) {
            head = head.next;
            saveStudentsToFile();
            return;
        }

        Student temp = head;

        while (temp.next != null) {

            if (temp.next.rollNo == roll) {
                temp.next = temp.next.next;
                saveStudentsToFile();
                return;
            }

            temp = temp.next;
        }

        System.out.println("Not Found");
    }
}